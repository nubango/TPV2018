#include "Logo.h"

Logo::Logo()
{
}

Logo::Logo(Vector2D pos, uint width, uint height, Texture * texture) : HUD(pos, width, height, texture)
{
}

Logo::~Logo()
{
}