#include "SDLError.h"

SDLError::SDLError(string s) : ArkanoidError(s)
{
}

SDLError::~SDLError()
{
}