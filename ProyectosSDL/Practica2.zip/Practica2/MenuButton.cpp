#include "MenuButton.h"

MenuButton::MenuButton()
{
}

MenuButton::MenuButton(Vector2D pos, uint width, uint height, Texture * texture) :
	ArkanoidObject(pos, width, height, texture)
{
}

MenuButton::~MenuButton()
{
}