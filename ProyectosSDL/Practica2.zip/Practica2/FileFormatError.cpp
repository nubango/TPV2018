#include "FileFormatError.h"

FileFormatError::FileFormatError(string s) : ArkanoidError(s)
{
}

FileFormatError::~FileFormatError()
{
}