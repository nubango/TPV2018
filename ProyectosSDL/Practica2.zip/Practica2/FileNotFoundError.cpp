#include "FileNotFoundError.h"

FileNotFoundError::FileNotFoundError(string s) : ArkanoidError(s)
{
}

FileNotFoundError::~FileNotFoundError()
{
}